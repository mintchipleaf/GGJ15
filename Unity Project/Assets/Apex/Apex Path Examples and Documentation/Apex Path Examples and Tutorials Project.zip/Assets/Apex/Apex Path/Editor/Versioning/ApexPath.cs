﻿/* Copyright © 2014 Apex Software. All rights reserved. */
using Apex.Editor.Versioning;

[assembly: ApexProductAttribute("Apex Path", "1.2.5", ProductType.Product)]
