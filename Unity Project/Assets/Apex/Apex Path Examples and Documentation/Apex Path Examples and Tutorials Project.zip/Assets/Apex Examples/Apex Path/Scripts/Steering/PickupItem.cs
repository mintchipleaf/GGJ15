﻿/* Copyright © 2014 Apex Software. All rights reserved. */
#pragma warning disable 1591
namespace Apex.Examples.Steering
{
    using UnityEngine;

    /// <summary>
    /// Represents an item that can be picked up
    /// </summary>
    public class PickupItem : MonoBehaviour
    {
        private void Start()
        {
            var master = FindObjectOfType<PickupMaster>();
            if (master != null)
            {
                master.RegisterItem(this);
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            var worker = other.GetComponent<PickupWorker>();
            if (worker != null)
            {
                if (worker.Pickup(this))
                {
                    this.collider.enabled = false;
                }
            }
        }
    }
}
